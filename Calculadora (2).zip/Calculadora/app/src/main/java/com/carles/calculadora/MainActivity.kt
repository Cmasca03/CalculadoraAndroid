package com.carles.calculadora

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.snackbar.Snackbar

// Clase principal de la actividad
class MainActivity : AppCompatActivity() {

    // Elementos de la interfaz
    private lateinit var tvResult: TextView // Muestra el resultado de la conversión
    private lateinit var etEuros: EditText // Campo de entrada para euros
    private lateinit var btnBitcoin: ImageButton // Botón para seleccionar Bitcoin
    private lateinit var btnEthereum: ImageButton // Botón para seleccionar Ethereum
    private lateinit var btnTether: ImageButton // Botón para seleccionar Tether
    private lateinit var btnXRP: ImageButton // Botón para seleccionar XRP
    private lateinit var btnSwitchMode: Button // Botón para alternar entre modos de conversión
    private lateinit var btnDelete: ImageButton // Botón para eliminar dígitos

    // Botones numéricos de la calculadora
    private lateinit var button0: Button
    private lateinit var button1: Button
    private lateinit var button2: Button
    private lateinit var button3: Button
    private lateinit var button4: Button
    private lateinit var button5: Button
    private lateinit var button6: Button
    private lateinit var button7: Button
    private lateinit var button8: Button
    private lateinit var button9: Button
    private lateinit var btnComa: Button // Botón para añadir una coma decimal
    private lateinit var btnCE: Button // Botón para limpiar el campo de entrada

    // Variables para el estado de la conversión
    private var selectedCrypto: String = "" // Criptomoneda seleccionada
    private var isEurosToCrypto: Boolean = true // Indica si la conversión es de euros a cripto
    private val cryptoRates = mapOf( // Tasas de conversión de criptomonedas
        "Bitcoin" to 59000.0,
        "Ethereum" to 2600.0,
        "Tether" to 2.0,
        "XRP" to 0.5
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Inicialización de elementos
        tvResult = findViewById(R.id.tvResult)
        etEuros = findViewById(R.id.etEuros)
        btnBitcoin = findViewById(R.id.btnBitcoin)
        btnEthereum = findViewById(R.id.btnEthereum)
        btnTether = findViewById(R.id.btnTether)
        btnXRP = findViewById(R.id.btnXRP)
        btnSwitchMode = findViewById(R.id.btnSwitchMode)
        btnDelete = findViewById(R.id.btnDelete)

        // Inicialización de botones de la calculadora
        button0 = findViewById(R.id.button)
        button1 = findViewById(R.id.button1)
        button2 = findViewById(R.id.button2)
        button3 = findViewById(R.id.button3)
        button4 = findViewById(R.id.button4)
        button5 = findViewById(R.id.button5)
        button6 = findViewById(R.id.button6)
        button7 = findViewById(R.id.button7)
        button8 = findViewById(R.id.button8)
        button9 = findViewById(R.id.button9)
        btnComa = findViewById(R.id.btnComa)
        btnCE = findViewById(R.id.btnCE)

        // Configuración de los botones de la calculadora
        setCalculatorButtonListeners()

        // Verifica si hay un estado guardado
        if (savedInstanceState != null) {
            selectedCrypto = savedInstanceState.getString("selectedCrypto", "")
            isEurosToCrypto = savedInstanceState.getBoolean("isEurosToCrypto", true)
            btnSwitchMode.text = if (isEurosToCrypto) "Convertir a Cripto" else "Convertir a Euros"
        } else {
            // Establecer el texto inicial del botón
            btnSwitchMode.text = "Convertir a Cripto"
        }

        // Selección de criptomoneda
        btnBitcoin.setOnClickListener {
            selectedCrypto = "Bitcoin"
            updateConversion() // Actualiza la conversión al seleccionar una criptomoneda
            showCryptoRate("Bitcoin") // Muestra la cotización
        }

        btnEthereum.setOnClickListener {
            selectedCrypto = "Ethereum"
            updateConversion()
            showCryptoRate("Ethereum") // Muestra la cotización
        }

        btnTether.setOnClickListener {
            selectedCrypto = "Tether"
            updateConversion()
            showCryptoRate("Tether") // Muestra la cotización
        }

        btnXRP.setOnClickListener {
            selectedCrypto = "XRP"
            updateConversion()
            showCryptoRate("XRP") // Muestra la cotización
        }



        // Alternar entre euros a cripto o cripto a euros
        btnSwitchMode.setOnClickListener {
            isEurosToCrypto = !isEurosToCrypto // Cambia el modo
            updateConversion() // Actualiza la conversión al cambiar de modo

            // Cambia el texto del botón dependiendo del modo
            if (isEurosToCrypto) {
                btnSwitchMode.text = "Convertir a Cripto"
                Toast.makeText(this, "Modo: Euros a Cripto", Toast.LENGTH_SHORT).show()
            } else {
                btnSwitchMode.text = "Convertir a Euros"
                Toast.makeText(this, "Modo: Cripto a Euros", Toast.LENGTH_SHORT).show()
            }
        }

        // Añadir TextWatcher para la conversión automática
        etEuros.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val text = s.toString()

                // Limitar los decimales a 2
                if (text.contains(",")) {
                    val parts = text.split(",")
                    if (parts.size > 1 && parts[1].length > 2) {
                        etEuros.setText(parts[0] + "," + parts[1].substring(0, 2)) // Limita a 2 decimales
                        etEuros.setSelection(etEuros.text.length) // Mueve el cursor al final del texto
                    }
                }

                // Llama a la conversión cada vez que cambie el texto
                updateConversion()
            }

            override fun afterTextChanged(s: Editable?) {}
        })

        // Botón de eliminar un dígito
        btnDelete.setOnClickListener {
            val currentText = etEuros.text.toString()
            if (currentText.isNotEmpty()) {
                // Elimina el último carácter
                etEuros.setText(currentText.dropLast(1))
                // Establece el cursor al final del texto
                etEuros.setSelection(etEuros.text.length)
            }
        }
    }

    // Guardar el estado al girar la pantalla
    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        // Guardar el estado de la selección de criptomoneda y modo de conversión
        outState.putString("selectedCrypto", selectedCrypto)
        outState.putBoolean("isEurosToCrypto", isEurosToCrypto)
    }

    // Restaurar el estado al girar la pantalla
    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        // Restaurar el estado de la selección de criptomoneda y modo de conversión
        selectedCrypto = savedInstanceState.getString("selectedCrypto", "")
        isEurosToCrypto = savedInstanceState.getBoolean("isEurosToCrypto", true)

        // Actualiza la interfaz de usuario
        btnSwitchMode.text = if (isEurosToCrypto) "Convertir a Cripto" else "Convertir a Euros"

        // Cambia el texto del resultado si hay una criptomoneda seleccionada
        if (selectedCrypto.isNotEmpty()) {
            updateConversion()
        }
    }
    // Función para mostrar la cotización de la criptomoneda seleccionada
    private fun showCryptoRate(crypto: String) {
        val rate = cryptoRates[crypto] ?: return // Obtiene la tasa de conversión
        val message = "La cotización actual de $crypto es $rate EUR"

        // Muestra un Snackbar en la parte superior de la pantalla
        val snackbar = Snackbar.make(findViewById(android.R.id.content), message, Snackbar.LENGTH_SHORT)
        snackbar.setAnchorView(findViewById(R.id.btnSwitchMode)) // Cambia esto a un botón o vista que esté en la parte superior
        snackbar.show()
    }
    // Configura los listeners para los botones numéricos
    private fun setCalculatorButtonListeners() {
        button0.setOnClickListener { appendToEditText("0") }
        button1.setOnClickListener { appendToEditText("1") }
        button2.setOnClickListener { appendToEditText("2") }
        button3.setOnClickListener { appendToEditText("3") }
        button4.setOnClickListener { appendToEditText("4") }
        button5.setOnClickListener { appendToEditText("5") }
        button6.setOnClickListener { appendToEditText("6") }
        button7.setOnClickListener { appendToEditText("7") }
        button8.setOnClickListener { appendToEditText("8") }
        button9.setOnClickListener { appendToEditText("9") }

        // Configura el botón de la coma
        btnComa.setOnClickListener {
            val currentText = etEuros.text.toString()
            // Añade la coma solo si no hay ninguna
            if (!currentText.contains(",")) {
                etEuros.setText(currentText + ",") // Concatenar la coma al texto actual
                etEuros.setSelection(etEuros.text.length) // Mover el cursor al final
            }
        }

        btnCE.setOnClickListener { etEuros.text.clear() } // Limpia el campo de entrada
    }

    // Añadir un dígito al campo de entrada
    private fun appendToEditText(value: String) {
        etEuros.append(value)
    }

    // Actualiza la conversión y muestra el resultado
    private fun updateConversion() {
        val input = etEuros.text.toString().replace(",", ".").toDoubleOrNull() // Convierte el texto a un número
        if (input != null && selectedCrypto.isNotEmpty()) {
            // Realiza la conversión según el modo seleccionado
            val result = if (isEurosToCrypto) {
                convertToCrypto(input, selectedCrypto)
            } else {
                convertToEuros(input, selectedCrypto)
            }
            displayResult(result) // Muestra el resultado
        } else {
            // Muestra un mensaje si la entrada es inválida
            if (selectedCrypto.isEmpty()) {
                tvResult.text = "Por favor, selecciona una criptomoneda."
            } else {
                tvResult.text = "Escribe una cantidad válida."
            }
        }
    }

    // Convierte euros a la criptomoneda seleccionada
    private fun convertToCrypto(euros: Double, crypto: String): Double {
        val rate = cryptoRates[crypto] ?: return 0.0 // Obtiene la tasa de conversión
        return euros / rate // Realiza la conversión
    }

    // Convierte la cantidad de criptomonedas a euros
    private fun convertToEuros(cryptoAmount: Double, crypto: String): Double {
        val rate = cryptoRates[crypto] ?: return 0.0 // Obtiene la tasa de conversión
        return cryptoAmount * rate // Realiza la conversión
    }

    // Muestra el resultado de la conversión en la interfaz
    private fun displayResult(result: Double) {
        val formattedResult = if (isEurosToCrypto) {
            String.format(" %.6f %s", result, selectedCrypto) // Formato para criptomonedas
        } else {
            String.format(" %.2f EUR (%s)", result, selectedCrypto) // Formato para euros
        }
        tvResult.text = formattedResult // Actualiza el TextView con el resultado
    }
}
